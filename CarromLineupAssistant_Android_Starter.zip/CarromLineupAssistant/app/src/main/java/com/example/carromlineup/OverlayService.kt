package com.example.carromlineup

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PathEffect
import android.graphics.DashPathEffect
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var guideView: GuideView? = null
    private var panel: LinearLayout? = null
    private var angle = 0f
    private var guideLength = 520f
    private var angleLabel: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (guideView == null) showOverlays()
        return START_STICKY
    }

    private fun showOverlays() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // The guide layer is transparent and non-touchable, so game controls remain usable.
        val guide = GuideView(this)
        val guideParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        windowManager.addView(guide, guideParams)
        guideView = guide

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xDD20242A.toInt())
        }

        val header = TextView(this).apply {
            text = "LINEUP  •  drag to move"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(4, 2, 4, 8)
        }
        angleLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        val rotateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = Button(this).apply {
            text = "− 5°"
            setOnClickListener { angle -= 5f; refreshGuide() }
        }
        val right = Button(this).apply {
            text = "+ 5°"
            setOnClickListener { angle += 5f; refreshGuide() }
        }
        rotateRow.addView(left, LinearLayout.LayoutParams(0, 48, 1f))
        rotateRow.addView(right, LinearLayout.LayoutParams(0, 48, 1f))

        val lengthRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val shorter = Button(this).apply {
            text = "Shorter"
            setOnClickListener { guideLength = (guideLength - 60f).coerceAtLeast(120f); refreshGuide() }
        }
        val longer = Button(this).apply {
            text = "Longer"
            setOnClickListener { guideLength = (guideLength + 60f).coerceAtMost(1400f); refreshGuide() }
        }
        lengthRow.addView(shorter, LinearLayout.LayoutParams(0, 48, 1f))
        lengthRow.addView(longer, LinearLayout.LayoutParams(0, 48, 1f))

        val close = Button(this).apply {
            text = "Close overlay"
            setOnClickListener { stopSelf() }
        }

        controls.addView(header)
        controls.addView(angleLabel)
        controls.addView(rotateRow)
        controls.addView(lengthRow)
        controls.addView(close)

        val panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 140
        }

        // Drag the header area to reposition the control panel.
        header.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = panelParams.x
                        startY = panelParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        panelParams.x = startX - (event.rawX - touchX).toInt()
                        panelParams.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(controls, panelParams)
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(controls, panelParams)
        panel = controls
        refreshGuide()
    }

    private fun refreshGuide() {
        angleLabel?.text = "Angle: ${angle.toInt()}°"
        guideView?.invalidate()
    }

    override fun onDestroy() {
        guideView?.let { runCatching { windowManager.removeView(it) } }
        panel?.let { runCatching { windowManager.removeView(it) } }
        guideView = null
        panel = null
        super.onDestroy()
    }

    private inner class GuideView(context: Context) : View(context) {
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 220, 255)
            strokeWidth = 5f
            style = Paint.Style.STROKE
        }
        private val dashedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            strokeWidth = 3f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(14f, 12f), 0f)
        }
        private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 210, 60)
            style = Paint.Style.FILL
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val startX = width / 2f
            val startY = height * 0.78f
            val radians = Math.toRadians(angle.toDouble())
            val endX = startX + (sin(radians) * guideLength).toFloat()
            val endY = startY - (cos(radians) * guideLength).toFloat()

            canvas.drawLine(startX, startY, endX, endY, linePaint)
            canvas.drawCircle(startX, startY, 11f, pointPaint)
            canvas.drawCircle(endX, endY, 8f, dashedPaint)
        }
    }
}
