# Carrom Lineup Assistant (Android starter)

A basic Android overlay prototype with:
- Transparent aiming line drawn over other apps
- Floating control panel
- Angle adjustment in 5-degree steps
- Guide length adjustment
- Draggable control panel

## Build
1. Install Android Studio.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK on your Android phone.

## Use
1. Open the app.
2. Tap **Grant overlay permission** and allow display over other apps.
3. Return to the app and tap **Start lineup overlay**.
4. Open Carrom Pool.
5. Use the floating panel to adjust the guide.
6. Tap **Close overlay** or reopen the app and tap **Stop overlay** to stop it.

## Important limitations
This is a manual guide, not an automatic solver. The line currently starts near the lower middle of the screen and points upward. It does not detect the striker, coins, pockets, board boundaries, or calculate collision/rebound physics. Screen layouts and Android manufacturer restrictions may affect overlay placement.

The guide window is deliberately non-touchable so it does not block Carrom Pool controls. Only the small floating control panel receives touches.
